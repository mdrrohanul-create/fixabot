import { Header } from '@/components/header'
import { PricingCard } from '@/components/pricing-card'

export default function Home() {
  const whatsappLink = 'https://wa.me/message/Q7XKD23256KEO1'

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 pt-12 pb-16 px-4 md:px-6">
      {/* Background glow effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-400/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-lime-400/5 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto">
        <Header />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Fixa Verse 1 */}
          <PricingCard
            title="Fixa Verse 1"
            currentPrice={60}
            features={[
              'Comprehensive algorithmic setup fine-tuned for high-frequency market trends.',
              'Delivers an exceptional average performance of 6 to 7 highly profitable outcomes out of 10 executions.',
              'Unlock precision-driven Sure Shot signals designed to eliminate market noise.',
              'Streamlined, intuitive dashboard built for rapid deployment.',
            ]}
            whatsappLink={whatsappLink}
          />

          {/* Fixa AI Auto Trading - Featured */}
          <PricingCard
            title="Fixa AI Auto Trading"
            oldPrice={150}
            currentPrice={85}
            features={[
              '100% Fully Autonomous AI Trading Engine running around the clock.',
              'Advanced Neural Networks independently analyze micro-market structures and execute instantaneous trades.',
              'Requires zero manual oversight, active technical analysis, or prior trading experience.',
              'Special promotion: Locked at just $85 before returning to the standard $150.',
            ]}
            isFeatured
            hasCountdown
            whatsappLink={whatsappLink}
          />

          {/* Fixa Verse 2 */}
          <PricingCard
            title="Fixa Verse 2"
            currentPrice={75}
            features={[
              'Next-tier upgraded system with deeper layer liquidity tracking.',
              'Access to high-priority VIP signal channels boasting enhanced execution accuracy.',
              'Integrated advanced risk-mitigation protocols to structurally protect your capital.',
              'Includes priority 24/7 technical customer support channels.',
            ]}
            whatsappLink={whatsappLink}
          />
        </div>
      </div>
    </main>
  )
}
