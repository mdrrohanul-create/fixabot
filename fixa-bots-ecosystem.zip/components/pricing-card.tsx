'use client'

import { useEffect, useState } from 'react'

interface PricingCardProps {
  title: string
  oldPrice?: number
  currentPrice: number
  features: string[]
  isFeatured?: boolean
  hasCountdown?: boolean
  whatsappLink: string
}

export function PricingCard({
  title,
  oldPrice,
  currentPrice,
  features,
  isFeatured = false,
  hasCountdown = false,
  whatsappLink,
}: PricingCardProps) {
  const [timeLeft, setTimeLeft] = useState<string>('')

  useEffect(() => {
    if (!hasCountdown) return

    const updateCountdown = () => {
      const now = new Date()
      const endOfMonth = new Date(
        now.getFullYear(),
        now.getMonth() + 1,
        0,
        23,
        59,
        59
      )
      const diff = endOfMonth.getTime() - now.getTime()

      if (diff <= 0) {
        setTimeLeft('Offer Expired!')
        return
      }

      const days = Math.floor(diff / (1000 * 60 * 60 * 24))
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
      const seconds = Math.floor((diff % (1000 * 60)) / 1000)

      setTimeLeft(
        `${days}d : ${hours.toString().padStart(2, '0')}h : ${minutes
          .toString()
          .padStart(2, '0')}m : ${seconds.toString().padStart(2, '0')}s`
      )
    }

    updateCountdown()
    const interval = setInterval(updateCountdown, 1000)
    return () => clearInterval(interval)
  }, [hasCountdown])

  return (
    <div
      className={`relative overflow-hidden rounded-3xl backdrop-blur-3xl transition-all duration-500 flex flex-col justify-between p-8 md:p-10 ${
        isFeatured
          ? 'border-2 border-cyan-400 bg-gradient-to-b from-slate-900 to-slate-950 shadow-xl shadow-cyan-400/20 hover:shadow-cyan-400/30 hover:border-lime-400'
          : 'border border-white/10 bg-slate-900/60 hover:border-cyan-400/30 hover:shadow-lg hover:shadow-cyan-400/10'
      } hover:-translate-y-2`}
    >
      {isFeatured && (
        <div className="absolute top-5 right-5">
          <div className="bg-gradient-to-r from-cyan-400 to-blue-500 text-black px-3 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider shadow-lg shadow-cyan-400/40">
            Limited Offer
          </div>
        </div>
      )}

      <div>
        <h2
          className={`text-2xl md:text-3xl font-bold mb-6 ${
            isFeatured
              ? 'bg-gradient-to-r from-cyan-400 to-lime-400 bg-clip-text text-transparent'
              : 'text-white'
          }`}
        >
          {title}
        </h2>

        <div className="mb-6 flex items-baseline gap-3">
          {oldPrice && (
            <span className="text-lg text-slate-400 line-through opacity-60">
              ${oldPrice}
            </span>
          )}
          <span className="text-4xl md:text-5xl font-bold text-white">
            ${currentPrice}
          </span>
        </div>

        {hasCountdown && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-3 mb-8">
            <div className="text-xs font-bold text-red-500 uppercase tracking-wider mb-2">
              Flash Sale Ends This Month!
            </div>
            <div className="text-lg font-bold text-white tracking-wide">
              {timeLeft}
            </div>
          </div>
        )}

        <ul className="space-y-4 mb-8 flex-grow">
          {features.map((feature, idx) => (
            <li
              key={idx}
              className="flex items-start gap-3 text-slate-300 text-sm md:text-base leading-relaxed"
            >
              <span
                className={`flex-shrink-0 text-lg font-bold ${
                  isFeatured ? 'text-lime-400' : 'text-cyan-400'
                }`}
              >
                ✦
              </span>
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </div>

      <a
        href={whatsappLink}
        target="_blank"
        rel="noopener noreferrer"
        className={`block text-center py-4 px-6 rounded-xl font-bold text-lg transition-all duration-300 ${
          isFeatured
            ? 'bg-gradient-to-r from-cyan-400 to-blue-500 text-black shadow-lg shadow-cyan-400/30 hover:shadow-cyan-400/50 hover:scale-105'
            : 'bg-white/10 text-white border border-white/20 hover:bg-white hover:text-black shadow-lg'
        }`}
      >
        Get Now
      </a>
    </div>
  )
}
