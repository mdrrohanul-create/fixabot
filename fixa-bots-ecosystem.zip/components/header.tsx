export function Header() {
  return (
    <header className="text-center mb-16 md:mb-20">
      <h1 className="text-4xl md:text-6xl font-black mb-4 tracking-tight">
        <span className="bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent">
          Fixa Bots
        </span>
        <br />
        <span className="bg-gradient-to-r from-cyan-400 to-lime-400 bg-clip-text text-transparent">
          Ecosystem
        </span>
      </h1>
      <p className="text-slate-300 text-lg md:text-xl max-w-2xl mx-auto leading-relaxed">
        Deploy institutional-grade automated trading algorithms designed to
        maximize conversion and profitability.
      </p>
    </header>
  )
}
